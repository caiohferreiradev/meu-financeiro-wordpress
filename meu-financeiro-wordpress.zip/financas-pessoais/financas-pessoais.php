<?php
/**
 * Plugin Name: Meu Financeiro
 * Description: Painel privado de controle financeiro mensal, com lançamentos, cartões, assinaturas, dívidas e metas.
 * Version: 1.0.4
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: OpenAI
 * License: GPL-2.0-or-later
 */

if (!defined('ABSPATH')) { exit; }

final class Meu_Financeiro {
    const VERSION = '1.0.4';
    const REST_NS = 'meu-financeiro/v1';

    public function __construct() {
        add_shortcode('meu_financeiro', [$this, 'shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'assets']);
        add_action('rest_api_init', [$this, 'routes']);
        add_filter('body_class', [$this, 'page_body_class']);
    }

    public function page_body_class($classes) {
        if (is_singular() && is_main_query()) {
            $post = get_queried_object();
            if ($post instanceof WP_Post && has_shortcode($post->post_content, 'meu_financeiro')) {
                $classes[] = 'mf-fullscreen-page';
            }
        }
        return $classes;
    }

    public function assets() {
        wp_register_style('meu-financeiro', plugins_url('assets/app.css', __FILE__), [], self::VERSION);
        wp_register_script('meu-financeiro', plugins_url('assets/app.js', __FILE__), [], self::VERSION, true);
    }

    public function shortcode() {
        if (!is_user_logged_in()) {
            return '<div class="mf-login"><h2>Seu espaço financeiro</h2><p>Entre na sua conta para abrir seu painel pessoal.</p>' . wp_login_form(['echo' => false, 'redirect' => get_permalink()]) . '</div>';
        }
        wp_enqueue_style('meu-financeiro');
        wp_enqueue_script('meu-financeiro');
        $config = [
            'api' => esc_url_raw(rest_url(self::REST_NS . '/data')),
            'nonce' => wp_create_nonce('wp_rest'),
            'monthNames' => ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
            'currency' => 'BRL',
        ];
        $inline = '<script>window.MeuFinanceiro = ' . wp_json_encode($config) . ';</script>';
        return $inline . '<div id="meu-financeiro-app" class="mf-app"><div class="mf-loading">Preparando seu painel…</div></div>';
    }

    public function routes() {
        register_rest_route(self::REST_NS, '/data', [
            [
                'methods' => 'GET', 'callback' => [$this, 'get_data'],
                'permission_callback' => [$this, 'can_access'],
            ],
            [
                'methods' => 'PUT', 'callback' => [$this, 'save_data'],
                'permission_callback' => [$this, 'can_access'],
            ],
        ]);
    }

    public function can_access() { return is_user_logged_in() && current_user_can('read'); }

    private function option_key() { return 'mf_data_user_' . get_current_user_id(); }

    private function blank_data() {
        return [
            'items' => [],
            'cards' => [],
            'subscriptions' => [],
            'debts' => [],
            'goals' => [],
        ];
    }

    public function get_data() {
        $data = get_option($this->option_key(), $this->blank_data());
        return rest_ensure_response($data);
    }

    public function save_data($request) {
        $json = $request->get_json_params();
        $data = is_array($json) && array_key_exists('data', $json) ? $json['data'] : $request->get_param('data');
        if (!is_array($data) && !is_object($data)) {
            return new WP_Error('invalid_data', 'Os dados enviados não são válidos.', ['status' => 400]);
        }
        $allowed = ['items', 'cards', 'subscriptions', 'debts', 'goals'];
        $safe = $this->blank_data();
        foreach ($allowed as $key) {
            if (isset($data[$key]) && is_array($data[$key])) {
                $safe[$key] = array_values(array_map([$this, 'sanitize_record'], $data[$key]));
            }
        }
        update_option($this->option_key(), $safe, false);
        return rest_ensure_response(['saved' => true]);
    }

    public function sanitize_record($record) {
        if (!is_array($record)) { return []; }
        $clean = [];
        foreach ($record as $key => $value) {
            $key = sanitize_key($key);
            if (is_bool($value) || is_numeric($value) || $value === null) { $clean[$key] = $value; }
            elseif (is_string($value)) { $clean[$key] = sanitize_text_field($value); }
        }
        return $clean;
    }
}

new Meu_Financeiro();
